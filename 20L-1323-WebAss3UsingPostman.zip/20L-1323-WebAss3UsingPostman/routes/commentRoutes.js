const express = require('express');
const { createComment, getComments } = require('../controllers/commentController');
const auth = require('../middleware/auth');

const router = express.Router({ mergeParams: true });

router.post('/', auth, createComment);
router.get('/', getComments);

module.exports = router;
