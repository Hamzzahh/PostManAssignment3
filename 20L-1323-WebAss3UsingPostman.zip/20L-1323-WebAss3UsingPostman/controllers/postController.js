const Post = require('../models/Post');

// Create post
exports.createPost = async (req, res) => {
    const { title, content } = req.body;
    const author = req.userId;

    try {
        const post = new Post({ title, content, author });
        await post.save();
        res.status(201).json(post);
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};

// Get all posts
exports.getPosts = async (req, res) => {
    try {
        const posts = await Post.find().populate('author', 'username');
        res.status(200).json(posts);
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};

// Get single post
exports.getPost = async (req, res) => {
    const postId = req.params.id;

    try {
        const post = await Post.findById(postId).populate('author', 'username');
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }
        res.status(200).json(post);
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};

// Update post
exports.updatePost = async (req, res) => {
    const postId = req.params.id;
    const { title, content } = req.body;

    try {
        const post = await Post.findOneAndUpdate(
            { _id: postId, author: req.userId },
            { title, content },
            { new: true }
        );
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }
        res.status(200).json(post);
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};

// Delete post
exports.deletePost = async (req, res) => {
    const postId = req.params.id;

    try {
        const post = await Post.findOneAndDelete({ _id: postId, author: req.userId });
        if (!post) {
            return res.status(404).json({ message: 'Post not found' });
        }
        res.status(200).json({ message: 'Post deleted' });
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};
