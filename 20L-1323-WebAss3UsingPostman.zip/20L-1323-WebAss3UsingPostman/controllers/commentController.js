
const Comment = require('../models/Comment');
const Post = require('../models/Post');

// Create comment
exports.createComment = async (req, res) => {
    const { content } = req.body;
    const author = req.userId;
    const post = req.params.postId;

    try {
        const newComment = new Comment({ content, author, post });
        await newComment.save();

        res.status(201).json(newComment);
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};

// Get comments for a post
exports.getComments = async (req, res) => {
    const postId = req.params.postId;

    try {
        const comments = await Comment.find({ post: postId }).populate('author', 'username');
        res.status(200).json(comments);
    } catch (error) {
        res.status(500).json({ message: 'Something went wrong' });
    }
};